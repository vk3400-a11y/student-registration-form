# Student Registration Form (Swing GUI)
Stores student records into a CSV file.