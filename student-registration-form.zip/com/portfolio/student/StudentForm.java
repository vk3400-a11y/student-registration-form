package com.portfolio.student;

import javax.swing.*;
import java.io.*;

public class StudentForm extends JFrame {
    JTextField name, roll, dept;
    JButton save;

    public StudentForm() {
        setTitle("Student Registration Form");
        setSize(400,300);
        setLayout(null);

        JLabel l1 = new JLabel("Name:");
        l1.setBounds(30,30,100,25);
        add(l1);
        name = new JTextField();
        name.setBounds(150,30,200,25);
        add(name);

        JLabel l2 = new JLabel("Roll No:");
        l2.setBounds(30,80,100,25);
        add(l2);
        roll = new JTextField();
        roll.setBounds(150,80,200,25);
        add(roll);

        JLabel l3 = new JLabel("Department:");
        l3.setBounds(30,130,100,25);
        add(l3);
        dept = new JTextField();
        dept.setBounds(150,130,200,25);
        add(dept);

        save = new JButton("Save");
        save.setBounds(150,180,100,30);
        add(save);

        save.addActionListener(e -> saveData());

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    void saveData() {
        String n = name.getText();
        String r = roll.getText();
        String d = dept.getText();
        if(n.isEmpty() || r.isEmpty() || d.isEmpty()) {
            JOptionPane.showMessageDialog(this,"Fill all fields!");
            return;
        }
        try {
            FileWriter fw = new FileWriter("students.csv", true);
            fw.write(r + "," + n + "," + d + "\n");
            fw.close();
            JOptionPane.showMessageDialog(this,"Saved!");
        } catch(Exception ex) {
            JOptionPane.showMessageDialog(this, ex.toString());
        }
    }

    public static void main(String[] args) {
        new StudentForm();
    }
}
